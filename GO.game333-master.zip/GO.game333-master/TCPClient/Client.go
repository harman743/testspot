package main

import (
	"bufio"
	"fmt"
	"net"
	"os"
	"strings"
)

// Helper method that will panic on an error, or print a successful message and continue
func check(err error, message string) {
	if err != nil {
		panic(err)
	}
	fmt.Printf("%s\n", message)
}

// type client struct {
// 	name       string
// 	connection net.Conn
// }

//
func connectToServer(portIn string) (c net.Conn) {
	CONNECT := "127.0.0.1:" + portIn
	c, err := net.Dial("tcp", CONNECT)
	check(err, "Connected to server.")
	return c
}

// func newClient(conn net.Conn, err error) (c client, err error) {

// 	connection, err := connectToServer()
// 	if err != nil {
// 		fmt.Println(err)
// 		return connection, err
// 	}

// 	return connection, err

// }

func ReceiveMessages(conn net.Conn, text string) {
	for {
		message, _ := bufio.NewReader(conn).ReadString('\n')
		fmt.Print("->: " + message)
		if strings.TrimSpace(string(text)) == "STOP" {
			fmt.Println("TCP client exiting...")
			return
		}
	}
}

// InitializeClient ...
func InitializeClient() {

	//User input
	// arguments := os.Args
	// if len(arguments) == 1 {
	// 	fmt.Println("Please provide host:port.")
	// 	return
	// }
	// port := arguments[1]

	port := "5555"

	conn := connectToServer(port)

	for {
		reader := bufio.NewReader(os.Stdin)
		fmt.Print(">> ")
		text, _ := reader.ReadString('\n')
		fmt.Fprintf(conn, text+"\n")

		go ReceiveMessages(conn, text)

		// message, _ := bufio.NewReader(conn).ReadString('\n')
		// fmt.Print("->: " + message)
		// if strings.TrimSpace(string(text)) == "STOP" {
		// 	fmt.Println("TCP client exiting...")
		// 	return
		// }
	}
}
